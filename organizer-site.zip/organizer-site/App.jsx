import Organizer from './Organizer';
export default function App() {
  return <Organizer />;
}